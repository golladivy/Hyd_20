package com.example.shop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.shop.entity.Shops;
import com.example.shop.service.ShopsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;



	
@RestController
public class ShopsController {
	@Autowired
	private ShopsService shopsService;
	
@PostMapping("/shopping1")
public Shops saveShops(@RequestBody Shops shops) {
     return shopsService.saveShops(shops);
}

@GetMapping("/shopping1") 
public List<Shops>fetchShopsList(){
	return shopsService.fetchShopsList();
	
}
@GetMapping("/shopping1/{Id}")
public Shops fetchShopsById(@PathVariable("Id") Long Id) {
    return ShopsService.fetchShopsById(Id);
}
@DeleteMapping("/shopping1/{Id}")
public String deleteShopsById(@PathVariable("Id") Long id) {
	shopsService.deleteShopsById(id);
	return "Shops deleted successfully" ;
	
}
 @PutMapping("/shopping1/{Id}")
 public Shops updateShops(@PathVariable("Id") Long Id,
		 @RequestBody Shops shops) {
	return shopsService.updatShops(Id, shops);
	 
 }
}
