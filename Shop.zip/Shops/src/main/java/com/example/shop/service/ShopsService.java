package com.example.shop.service;

import java.util.List;

import com.example.shop.entity.Shops;

public interface ShopsService {
public Shops saveShops(Shops shops);
public List<Shops>fetchShopsList();
public static Shops fetchShopsById(Long Id) {
	// TODO Auto-generated method stub
	return null;
}
public void deleteShopsById(Long Id);
public Shops updatShops(Long Id,Shops shops);
} 
