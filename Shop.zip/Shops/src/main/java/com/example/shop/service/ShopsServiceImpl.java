package com.example.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shop.entity.Shops;
import com.example.shop.repository.ShopsRepository;

@Service 
public class ShopsServiceImpl implements ShopsService {
 @Autowired
public ShopsRepository shopsRepository;

@Override
public Shops saveShops(Shops shops) {
	// TODO Auto-generated method stub
	return shopsRepository.save(shops);
}

@Override
public List<Shops> fetchShopsList() {
	// TODO Auto-generated method stub
	return shopsRepository.findAll();
}

public Shops fetchShopsById(Long Id) {
	// TODO Auto-generated method stub
	return shopsRepository.findById(Id).get(); 
}

@Override
public void deleteShopsById(Long Id) {
	// TODO Auto-generated method stub
	shopsRepository.deleteById(Id);
}

@Override
public Shops updatShops(Long Id, Shops shops) {
	// TODO Auto-generated method stub
	Shops s1=shopsRepository.findById(Id).get();
	return s1;
	    }

	       
}

